<!DOCTYPE html>
<html lang="pt-br">
<head>
<link rel="stylesheet" href="CSS/login.css">
<title>Login</title>
<link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
</head>

 
  <body>
 
    <div class="login-page">
      <div class="form">
        <div class="login">
          <div class="login-header">

            
</div>

</head>
<body>
          <div class="background">
              <div class="shape"></div>
              <div class="shape"></div>
          </div>
          <form action="Login_e_cadastro_usuario/loginCodigo.php" method="post">
            <br>
            <img src="img/RazLogoCrop.png" width="90" height="100" alt="">
            <h3>Raz AutoParts</h3>
              <label for="username">Login</label>
              <input type="text" placeholder="Seu login:" name="login">
      
              <label for="Senha">Senha</label>
              <input type="Password" placeholder="Sua senha:" name="senha">
      
            <button href="table.php" type="submit" class="custom-btn btn-1">ENTRAR</button>
                          
          </form>
      </body>
      </html>