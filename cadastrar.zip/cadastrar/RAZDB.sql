create database RAZ;
use RAZ;
drop database RAZ;

create table usuarios_tb(
id_usu int primary key auto_increment,  -- ids podem ser cpfs, mas isso pode gerar erros, então resortei a deixar ids como algo separado.
nome_usu varchar(50) not null, -- nome do usuario, pode ser repetido, mas login não.
email_usu varchar(50), -- email.
login_usu varchar(50) unique not null, -- cada login é unico.
senha_usu varchar(50) -- senhas são individuais, fazer delas UNIQUEs pode comprometer segurança.
);
insert into usuarios_tb(login_usu,email_usu,senha_usu)values('root','root@mail.com',123);

create table categorias_tb( -- categorias de produtos
id_categ int primary key auto_increment,
nome_categ varchar(100) not null
);
insert into categorias_tb(nome_categ) values ('c');

create table Fornecedores_tb( -- fornecedores de produtos, não veiculos,
id_forn int primary key auto_increment,
nome_forn varchar(50)
);
insert into Fornecedores_tb(nome_forn) values ('c');

create table marcas_tb( -- essa seria a concessionaria/empresa/fabrica que produz carros.
id_marca int auto_increment primary key,
nome_marca varchar(50) unique
);
insert into marcas_tb(nome_marca) values ('c');

CREATE TABLE clientes_tb (
id_cli INT PRIMARY KEY auto_increment,
nome_cli VARCHAR(255) unique,
email_cli VARCHAR(255),
cpf_cli VARCHAR(11) unique,
cnpj_cli VARCHAR(14) unique
);

create table produtos_tb(
id_prod int primary key auto_increment,
nome_prod varchar(100) unique,
quant_prod int not null,
descricao_prod varchar(9999),
preco_prod int,

categoria_prod int,
constraint Categ_prod_fk foreign key (categoria_prod) references categorias_tb(id_categ),

fornecedor_prod int,
constraint forn_prod_fk foreign key (fornecedor_prod) references fornecedores_tb(id_forn)
);

CREATE TABLE IF NOT exists veiculos_tb(
id_veic int primary key auto_increment not null,
placa_veic varchar(10) unique not null,
nome_veic varchar (100) not null,
anofabrica_veic varchar(4) not null,
anomodelo_veic varchar (4) not null,
cor_veic varchar (15) not null,
cambio_veic varchar(10) not null,
combustivel_veic varchar(10) not null,

marca_veic int,
FOREIGN KEY (marca_veic) REFERENCES marcas_tb(id_marca),

cliente_veic int,
FOREIGN KEY (cliente_veic) REFERENCES clientes_tb(id_cli)
);

create table vendas_tb( -- essa é a tabela de relatorios, ela só armazena quando uma venda é feita
id_venda int primary key auto_increment,
quant_venda int not null,
preco_total_vendas int not null,
data_venda datetime,

produto_venda int,
constraint prod_id_fk foreign key (produto_venda) references produtos_tb(id_prod),

cliente_venda int,
constraint cliente_id_fk foreign key (cliente_venda) references clientes_tb(id_cli)
);

select * from clientes_tb;
select * from vendas_tb;
select * from produtos_tb;