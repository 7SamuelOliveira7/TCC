<?php
if(!isset($_SESSION)){
echo "<script>
            alert('Não Fez Login!');
            window.location.href = 'login.php';
          </script>";
    die();
} else {
    
}
?>