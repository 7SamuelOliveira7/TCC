<?php
include("conn2.php");

$sql = "SELECT * FROM vendas_tb ";
$res = $conn->query($sql);

function getNomeProduto($id){

require('conn.php');
$query =$pdo->prepare('select * from produtos_tb where id_prod = :id');
$query->execute([':id'=>$id]);
$resultado = $query->fetch();
return $resultado['nome_prod'];

};
function getNomeCliente($id){

require('conn.php');
$query =$pdo->prepare('select * from clientes_tb where id_cli = :id');
$query->execute([':id'=>$id]);
$resultado = $query->fetch();
return $resultado['nome_cli'];

}
function getEmailCliente($id){

    require('conn.php');
    $query =$pdo->prepare('select * from clientes_tb where id_cli = :id');
    $query->execute([':id'=>$id]);
    $resultado = $query->fetch();
    return $resultado['email_cli'];
    
    }

if ($res && $res->num_rows > 0) {
    $html = "<table border='1'>";

    $html .= "<td>Nome do Produto</td>";
    $html .= "<td>Quantidade Vendida</td>";
    $html .= "<td>Preço Total</td>";
    $html .= "<td>Cliente</td>";
    $html .= "<td>Email</td>";
    $html .= "<td>Data de Venda</td>";

    while ($row = $res->fetch_object()) {
        $html .= "<tr>";
       
        $html .= "<td>" . getNomeProduto($row->produto_venda) . "</td>";
        $html .= "<td>" . $row->quant_venda . " Unidades</td>";
        $html .= "<td>R$" . $row->preco_total_vendas. "</td>";
        $html .= "<td>" . getNomeCliente($row->cliente_venda) . "</td>";
        $html .= "<td>" . getEmailCliente($row->cliente_venda) . "</td>";
        $html .= "<td>" . $row->data_venda . "</td>";
      
        $html .= "</tr>";
    }
    $html .= "</table>";
} else {
    $html = "Nada encontrado";
}

use Dompdf\Dompdf;
require_once 'dompdf/autoload.inc.php';

$dompdf = new Dompdf();

$dompdf->loadHtml($html);

$dompdf->set_option('defaultFont', 'sans');

$dompdf->setPaper('A4', 'portrait');

$dompdf->render();

$dompdf->stream();
?>