<?php
try{
$pdo = new pdo('mysql:host=localhost;dbname=RAZ','root','usbw');

$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
$pdo->exec("SET CHARACTER SET utf8");
}catch(PDOException $error){
    echo 'Error'.$error->getMessage();

}

?>