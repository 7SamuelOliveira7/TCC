<html>
    <link rel="stylesheet" href="pop.css">
<div class="row pop-up">
  <div class="box small-6 large-centered">
    <a href="#" class="close-button">&#10006;</a>
    <h3>Bem-Vindo</h3>
    <p>Seja Bem-Vindo <?php echo $_GET['nome']; ?></p>
  </div>
</div>

</html>