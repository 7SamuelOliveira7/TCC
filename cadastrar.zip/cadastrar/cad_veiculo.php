<?php

session_start();
require('protected.php');
require("conn.php");

    $clienteFetch = $pdo -> prepare('SELECT * from clientes_tb');
    $clienteFetch -> execute();
    $clientes= $clienteFetch -> fetchall();

?>

<html>
<nav class="navbar bg-body-tertiary">
  <div class="container-fluid">

  <a class="navbar-brand" style=' font-family: Monospace; font-weight: 100; font-size:20px'><img src="./img/RazLogoCrop.png" >ㅤRaz AutoParts</a>

    <form action="login.php" method="post">
                <form class="d-flex" role="search">
                <button class="btn btn-outline-success" type="submit">Sair</button>
                </form>
                </form>
    
  </div>
</nav>

<link rel="stylesheet" href="menu/sidebar.css">
<link rel="stylesheet" href="CSS/teste_2.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
<nav role="navigation">
<div id="menuToggle" style="filter: blur 10px;z-index: 255;">
    <input type="checkbox" />
    
    <span></span>
    <span></span>
    <span></span>
    
   
    <ul id="menu">

    <a href="table.php"><li> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" 
      class="bi bi-search" viewBox="0 0 16 16">
      <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l
      -3.85-3.85a1.007 1.007 0 0  0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
      </svg> Procurar Peça</li></a>

      <a href="index.php"><li> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-clipboard-plus" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M8 7a.5.5 0 0 1 .5.5V9H10a.5.5 0 0 1 0 1H8.5v1.5a.5.5 0 0 1-1 0V10H6a.5.5 0 0 1 0-1h1.5V7.5A.5.5 0 0 1 8 7z"/>
      <path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1v-1z"/>
      <path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h3zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3z"/>
      </svg> Cadastrar Peças</li></a>

      <a href="cad_cliente.php"><li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" 
      class="bi bi-postcard" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2ZM1 4a1 
      1 0 0 1 1-1h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V4Zm7.5.5a.5.5 0 0 0-1 0v7a.5.5 0 0 0 1 
      0v-7ZM2 5.5a.5.5 0 0 1 .5-.5H6a.5.5 0 0 1 0 1H2.5a.5.5 0 0 1-.5-.5Zm0 2a.5.5 0 0 1 .5-.5H6a.5.5 0 0 1 0
      1H2.5a.5.5 0 0 1-.5-.5Zm0 2a.5.5 0 0 1 .5-.5H6a.5.5 0 0 1 0 1H2.5a.5.5 0 0 1-.5-.5ZM10.5 5a.5.5 0 0 0-.5.
      5v3a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5v-3a.5.5 0 0 0-.5-.5h-3ZM13 8h-2V6h2v2Z"/>
      </svg>   Cadastrar Cliente</li></a>

      <a href="cad_veiculo_produto.php"><li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-inboxes" viewBox="0 0 16 16">
        <path d="M4.98 1a.5.5 0 0 0-.39.188L1.54 5H6a.5.5 0 0 1 .5.5 1.5 1.5 0 0 0 3 0A.5.5 0 0 1 10 5h4.46l-3.05-3.812A.5.5 0 0 0 11.02 1H4.98zm9.954 5H10.45a2.5 2.5 0 0 1-4.9 0H1.066l.32 2.562A.5.5 0 0 0 1.884 9h12.234a.5.5 0 0 0 .496-.438L14.933 6zM3.809.563A1.5 1.5 0 0 1 4.981 0h6.038a1.5 1.5 0 0 1 1.172.563l3.7 4.625a.5.5 0 0 1 .105.374l-.39 3.124A1.5 1.5 0 0 1 14.117 10H1.883A1.5 1.5 0 0 1 .394 8.686l-.39-3.124a.5.5 0 0 1 .106-.374L3.81.563zM.125 11.17A.5.5 0 0 1 .5 11H6a.5.5 0 0 1 .5.5 1.5 1.5 0 0 0 3 0 .5.5 0 0 1 .5-.5h5.5a.5.5 0 0 1 .496.562l-.39 3.124A1.5 1.5 0 0 1 14.117 16H1.883a1.5 1.5 0 0 1-1.489-1.314l-.39-3.124a.5.5 0 0 1 .121-.393zm.941.83.32 2.562a.5.5 0 0 0 .497.438h12.234a.5.5 0 0 0 .496-.438l.32-2.562H10.45a2.5 2.5 0 0 1-4.9 0H1.066z"/>
        </svg> Cadastrar Compatibilidade</li></a>

      

      <a href="relatorio.php"><li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" 
      class="bi bi-list-ul" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 
      .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm-3 1a1 1 
      0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
      </svg> Ver Relatórios</li></a>
      
      <a href="Sobre_Nos.php"><li><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
      <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088
      -.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
      </svg> Informações</li></a>
    </ul>
  </div>
</nav>
    </div>   
    <body class="fundo">
    <link rel="stylesheet" href="CSS/hf.css">
    <footer>
        <form action="CRUD/cad_veic.php" method="post" style="display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    margin: 0 auto;
    width: 50%;
    max-width: 500px;">
            <h1>Cadastrar Veículo</h1>
            
            <input type="text" name='placa_veic' require placeholder="Placa"><br>
            <input type="text" name='nome_veic' require placeholder="Nome do Veiculo"><br>
            <input type="text" name='anofabrica_veic' require placeholder="Ano de fabrica"><br>
            <input type="text" name='anomodelo_veic' require placeholder="Ano do modelo"><br>
            <input type="text" name='cor_veic' require placeholder="Cor do veiculo"><br>
            <input type="text" name='cambio_veic' require placeholder="Cambio"><br>
            <input type="text" name='combustivel_veic' require placeholder="Combustivel"><br>
            <input type="text" name='marca_veic' require placeholder="Marca do veiculo" >
            <select name="cliente_veic" id="" style="width:300px">
                <option value="" style="color:black">Escolha um Cliente</option>
                <?php
                foreach($clientes as $x){
                    echo '<option style="color:black" value="'.$x['id_cli'].'">'.$x['nome_cli'].'</option>';
                }
                ?>
           </select>
            <br>
            <div>
            <a href="table.php"><input class ="custom-btn btn-2" style="width:80px" value=VOLTAR></input></a><span style="color:rgba(0,0,0,0)">ㅤㅤㅤㅤㅤ</span><a href=""><input type='submit' style="width:100px" class="custom-btn btn-2" value='CADASTRAR'></a>
                </div>
        </form>
    </footer>
</body>
</html>